create database BackEnd;

use BackEnd;

create table User(
     id int auto_increment not null primary key,
     email varchar(50) not null unique,
     username varchar(50) default '匿名',
     password varchar(255) not null
)character set = utf8mb4 comment '用户表';

create table Bill(
     id int auto_increment not null primary key,
     user_id int,
     money float4 default 0,
     type bool,
     purpose char(4),
     date datetime,
     description varchar(255),
     foreign key Bill(user_id) references User(id)
)character set = utf8mb4 comment '账单表';