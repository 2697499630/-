package org.BackEndGroup.demo;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@MapperScan("org.BackEndGroup.demo.Mapper") // 扫描 Mapper 接口所在的包
public class BackEndEngineeringApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackEndEngineeringApplication.class, args);
	}

}
