package org.BackEndGroup.demo.Common.Config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class CorsConfig implements WebMvcConfigurer {

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        // 配置跨域请求
        registry.addMapping("/**") // 允许所有路径跨域
                .allowedOrigins("http://localhost:8080") // 允许指定的前端地址（可以多个）
                .allowedMethods("GET", "POST", "PUT", "DELETE") // 允许的HTTP方法
                .allowedHeaders("*") // 允许的请求头
                .allowCredentials(true) // 是否允许携带认证信息（如cookies）
                .maxAge(3600); // 预检请求的缓存时间，单位是秒
    }
}
