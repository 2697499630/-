package org.BackEndGroup.demo.Common;

public class Response<T> {
    private int code;       // 响应码，例如200表示成功，400表示请求错误
    private String message; // 响应消息
    private T data;         // 泛型数据，可以是任何类型

    // 构造函数
    public Response(int code, String message, T data) {
        this.code = code;
        this.message = message;
        this.data = data;
    }

    // 成功返回的静态方法
    public static <T> Response<T> success(T data) {
        return new Response<>(200, "Success", data);
    }

    // 失败返回的静态方法
    public static <T> Response<T> failure(int code, String message) {
        return new Response<>(code, message, null);
    }

    // Getter 和 Setter 方法
    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }
}
