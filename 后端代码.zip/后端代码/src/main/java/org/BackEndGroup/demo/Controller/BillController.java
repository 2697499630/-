package org.BackEndGroup.demo.Controller;

import org.BackEndGroup.demo.Common.Response;
import org.BackEndGroup.demo.Entity.Bill;
import org.BackEndGroup.demo.Service.BillService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/apis/bill")
public class BillController {

    @Autowired
    private BillService billService;

    @GetMapping("/get-all-bill/{userId}")
    public Response<List<Bill>> getAllBill(@PathVariable int userId) {
        return Response.success(billService.selectAllByUserId(userId));
    }

    @PostMapping("/add")
    public Response<Void> addBill(@RequestBody Bill bill) {
        try {
            billService.addBill(bill);
            return Response.success(null);
        }catch (Exception e) {
            return Response.failure(400, e.getMessage());
        }
    }

    @PutMapping("/update")
    public Response<Void> updateBill(@RequestBody Bill bill) {
        try {
            billService.updateBill(bill);
            return Response.success(null);
        }catch (Exception e) {
            return Response.failure(400, e.getMessage());
        }
    }

    @DeleteMapping("/delete")
    public Response<Void> deleteBill(@RequestBody Bill bill) {
        try {
            billService.deleteBill(bill);
            return Response.success(null);
        }catch (Exception e) {
            return Response.failure(400, e.getMessage());
        }
    }
}
