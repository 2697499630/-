package org.BackEndGroup.demo.Controller;

import org.BackEndGroup.demo.Common.Response;
import org.BackEndGroup.demo.Entity.User;
import org.BackEndGroup.demo.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/apis/user")
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping("/register")
    public Response<User> Register(@RequestBody User user) {
        try {
            return Response.success(userService.save(user));
        }catch (Exception e) {
            return Response.failure(400, e.getMessage());
        }
    }

    @PostMapping("/login")
    public Response<User> Login(@RequestBody User user) {
        try {
            User returnUser = userService.login(user);
            return Response.success(returnUser);
        }catch (Exception e) {
            return Response.failure(400, e.getMessage());
        }
    }
}
