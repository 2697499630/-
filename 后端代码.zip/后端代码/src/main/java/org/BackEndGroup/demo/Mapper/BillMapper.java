package org.BackEndGroup.demo.Mapper;

import org.BackEndGroup.demo.Entity.Bill;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface BillMapper {

    @Insert("INSERT INTO `Bill` (user_id, money, type, purpose, date, description) VALUES (#{userId}, #{money}, #{type}, #{purpose}, #{date}, #{description})")
    void insertBill(Bill bill);

    @Update("UPDATE `Bill` SET money=#{money}, type=#{type}, purpose=#{purpose}, description=#{description} WHERE id = #{id}")
    void updateBill(Bill bill);

    @Delete("DELETE FROM `Bill` WHERE id = #{id}")
    void deleteBill(int id);

    @Select("SELECT * FROM `Bill` WHERE id = #{id}")
    Bill selectBill(int id);

    @Select("SELECT * FROM `Bill` WHERE user_id = #{userId}")
    List<Bill> selectAllBill(int userId);
}
