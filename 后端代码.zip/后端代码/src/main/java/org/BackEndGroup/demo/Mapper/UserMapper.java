package org.BackEndGroup.demo.Mapper;

import org.BackEndGroup.demo.Entity.User;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface UserMapper {

    @Insert("INSERT INTO `User` (email, username, password) VALUES (#{email}, #{username}, #{password})")
    @Options(useGeneratedKeys = true, keyProperty = "id") // 自动获取自增主键的值
    void insert(User user);

    @Select("SELECT * FROM `User` WHERE email = #{email}")
    User findByEmail(String email);

}
