package org.BackEndGroup.demo.Service;

import org.BackEndGroup.demo.Entity.Bill;
import org.BackEndGroup.demo.Mapper.BillMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class BillService {

    @Autowired
    private BillMapper billMapper;

    public List<Bill> selectAllByUserId(int userId) {
        return billMapper.selectAllBill(userId);
    }

    public void addBill(Bill bill) {
        if (bill == null) {
            throw new RuntimeException("bill is null");
        }
        if (bill.getUserId() <= 0) {
            throw new RuntimeException("bill.userId error");
        }
        bill.setDate(LocalDateTime.now());
        billMapper.insertBill(bill);
    }

    public void updateBill(Bill bill) {
        if (bill == null) {
            throw new RuntimeException("newBill is null");
        }
        if (bill.getUserId() <= 0) {
            throw new RuntimeException("bill.userId error");
        }
        billMapper.updateBill(bill);
    }

    public void deleteBill(Bill bill) {
        if (bill == null) {
            throw new RuntimeException("bill is null");
        }
        Bill delBill = billMapper.selectBill(bill.getId());
        if (delBill == null) {
            throw new RuntimeException("delBill is null");
        }
        if (delBill.getUserId() != bill.getUserId()) {
            throw new RuntimeException("bill.userId error");
        }
        billMapper.deleteBill(bill.getId());
    }
}
