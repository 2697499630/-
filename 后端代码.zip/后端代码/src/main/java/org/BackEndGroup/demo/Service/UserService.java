package org.BackEndGroup.demo.Service;

import org.BackEndGroup.demo.Entity.User;
import org.BackEndGroup.demo.Mapper.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Autowired
    private UserMapper userMapper;

    public User save(User user) {
        if (user.getEmail().isBlank() || user.getPassword().isBlank()) {
            throw new RuntimeException("User Info Error");
        }
        userMapper.insert(user);
        return userMapper.findByEmail(user.getEmail());
    }

    public User login(User user){
        if (user == null) {
            throw new RuntimeException("User Info Error");
        }
        User loginUser = findByEmail(user.getEmail());
        if (loginUser == null) {
            throw new RuntimeException("User not exists");
        }
        if (!loginUser.getPassword().equals(user.getPassword())) {
            throw new RuntimeException("User Input Error");
        }
        return loginUser;
    }

    public User findByEmail(String email) {
        if (email == null || email.isEmpty()) {
            throw new RuntimeException("User Info Error");
        }
        return userMapper.findByEmail(email);
    }
}
