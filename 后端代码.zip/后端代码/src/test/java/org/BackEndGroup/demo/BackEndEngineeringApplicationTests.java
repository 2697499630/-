package org.BackEndGroup.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackEndEngineeringApplicationTests {

	@Test
	void contextLoads() {
	}

}
