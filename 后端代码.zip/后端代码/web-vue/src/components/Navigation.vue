<script setup lang="ts">
import { useRouter } from "vue-router";
const router = useRouter();

</script>

<template>
    <div class="nav">
        <img src="../assets/images/logo.png" alt="" class="logo-font" @click="router.push({name:'Index'})">

        <img src="../assets/images/avatar/default.png" alt="" class="avatar">
        <span class="btn" @click="router.push({name:'Login'})">登录</span>
        <span class="btn" @click="router.push({name:'Register'})">注册</span>
    </div>
</template>

<style scoped>
    .nav {
        width: 100%;
        height: 60px;
        background-color: #393D49;
        justify-content: center;
        line-height: 40px;
    }
    .logo-font{
        margin-left: 18%;
        cursor: pointer;
    }
    .avatar{
        width: 40px;
        height: 40px;
        margin-left: 45%;
    }
    .btn{
        display: inline-block;
        color:#A6B3B3;
        margin-top: 10px;
        margin-left:10px;
        cursor: pointer;
    }
</style>