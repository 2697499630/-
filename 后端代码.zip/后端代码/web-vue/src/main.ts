import { createApp } from 'vue';
import { createRouter, createWebHistory } from 'vue-router';
import "./global.css";

import App from "@/App.vue";
import Index from "@/views/Index.vue";
import Login from "@/views/Login.vue";
import Register from '@/views/Register.vue';

const routes = [
    {
        name: "Index",
        path: "/",
        component: Index,
    },
    {
        name: "Login",
        path: "/login",
        component: Login,
    },
    {
        name: "Register",
        path: "/register",
        component: Register,
    }
]

const router = createRouter(
    {
        history: createWebHistory(),
        routes
    }
);

const app = createApp(App);
app.use(router);
app.mount('#app');