<script setup lang="ts">
import Navigation from "@/components/Navigation.vue";
import img1 from "@/assets/images/a1.png";
import img2 from "@/assets/images/a2.png";
import img3 from "@/assets/images/a3.png";
import img4 from "@/assets/images/a4.png";

let timelineData = [
        {
          title: "还在为携带账本烦恼?",
          description: "现在只需要连接网络，打开浏览器，便可以随时随地进行记录。当然，我们是免费的。",
          img: img1,
        },
        {
          title: "大账目轻松计算!",
          description: "减轻你的计算负担，让记账更从容。",
          img: img2,
        },
        {
          title: "担心查看?",
          description: "没问题，我们帮你准备了Excel导出。",
          img: img3,
        },
        {
          title: "其他标题",
          description: "这里可以添加其他描述。",
          img: img4,
        },
      ];
</script>

<template>
    <Navigation/>
    <div class="timeline">
        <div
        v-for="(item, index) in timelineData"
        :key="index"
        class="timeline-item"
        :class="{'left': index % 2 === 0, 'right': index % 2 !== 0}"
        >
        <div class="timeline-content">
            <img :src="item.img" alt="Image" />
            <div class="text">
            <h3>{{ item.title }}</h3>
            <p>{{ item.description }}</p>
            </div>
        </div>
        </div>
    </div>
</template>

<style scoped>
.timeline {
  position: relative;
  padding: 40px 0;
  width: 100%;
  max-width: 1200px;
  margin: 0 auto;
}

.timeline-item {
  display: flex;
  align-items: center;
  margin: 20px 0;
  position: relative;
}

.timeline-item.left .timeline-content {
  flex-direction: row-reverse;
}

.timeline-item.right .timeline-content {
  flex-direction: row;
}

.timeline-content {
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  max-width: 900px;
}

.timeline-content img {
  width: 200px;
  height: auto;
  border-radius: 8px;
  object-fit: cover;
}

.timeline-content .text {
  flex: 1;
  padding: 0 20px;
}

.timeline-content .text h3 {
  margin: 0 0 10px;
  font-size: 18px;
  color: #333;
}

.timeline-content .text p {
  margin: 0;
  font-size: 14px;
  color: #666;
}

.timeline::before {
  content: "";
  position: absolute;
  top: 0;
  left: 50%;
  transform: translateX(-50%);
  width: 2px;
  height: 100%;
  background-color: #ccc;
}

.timeline-item::before {
  content: "";
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 16px;
  height: 16px;
  border-radius: 50%;
  background-color: #1e90ff;
}
</style>