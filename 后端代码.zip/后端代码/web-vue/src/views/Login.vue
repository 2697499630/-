<script setup lang="ts">
import Navigation from "@/components/Navigation.vue";
</script>
<template>
    <Navigation/>
</template>